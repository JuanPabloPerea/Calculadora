def Suma(num1 ,num2):
    res = num1+num2
    print(res)

def Resta(num1 ,num2):
   res = num1-num2
   print(res)

def Multi(num1 ,num2):
    res = num1*num2
    print(res)
        
def Div(num1 ,num2):
    if num2==0:
        print("numero incorrecto, porfavor intente de nuevo")
    else:
        res=num1/num2
        print(res)

