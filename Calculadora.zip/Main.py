import Operacion
class Calculadora:
        def __init__(self, numero1, numero2):
            self.numero1 = numero1
            self.numero2 = numero2

        Operacion.Suma(1 ,2)
        Operacion.Div(1, 0.6)
        Operacion.Multi(8, -7)
        Operacion.Resta(7, (1/5))
    
    
